Many tests specify results here.

Except for this README, no file from this directory should appear in a project or be distributed.
