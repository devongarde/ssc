This is a test web side based on the corrupt press website (corruptpress.com). It is currently only used in by-hand tests.

Oh, and if you enjoy poetry, please do visit corrupt press!