ISO/IEC 40500(E)


To access the document, open the file "C058625e.html".

The folder "C058625e_FILES" contains the various components of the document.















