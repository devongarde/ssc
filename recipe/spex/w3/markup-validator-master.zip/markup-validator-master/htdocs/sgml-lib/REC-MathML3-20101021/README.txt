Origin: http://www.w3.org/Math/DTD/
        http://www.w3.org/Math/DTD/mathml3-dtd.zip
Retrieved 2010-06-13

Removed: predefined.ent (unreferenced, we have one in REC-xml-entity-names)
