# Security Policy

## Supported Versions

SSC is alpha software under active development. This is not (yet) a stable version, let alone a release version.
Thus, in effect, nothing is currently supported. However, any vulnerability report will be gladly received and
quickly addressed.

Until a release version becomes available, it is strongly recommended that you do not use SSC to analyse untrusted HTML.

## Reporting a Vulnerability

Please email a report to mail@ssc.lu.
